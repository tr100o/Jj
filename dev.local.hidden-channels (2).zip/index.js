// Hidden Channels Viewer 0.1.3 (hand-written JS, read-only, no network, no token)
var TAG = '[hidden-channels]';
var __plugin = (typeof plugin === 'function') ? plugin : function (o) { return o; };
var VIEW = BigInt(1024); // VIEW_CHANNEL = 1 << 10
var TYPES = {0:'نصية',2:'صوتية',5:'إعلانات',13:'ستيج',15:'منتدى',16:'وسائط'};

function findBy(pred) {
  var mods = globalThis.modules;
  if (!mods) return undefined;
  var ids = Object.keys(mods);
  for (var i = 0; i < ids.length; i++) {
    var m = mods[ids[i]];
    if (!m || !m.isInitialized) continue; // never force-initialize modules
    var ex = m.publicModule && m.publicModule.exports;
    var cands = [ex && ex.default, ex];
    for (var j = 0; j < cands.length; j++) {
      try { if (cands[j] && pred(cands[j])) return cands[j]; } catch (e) {}
    }
  }
}
function store(name) { return findBy(function (c) { return typeof c.getName === 'function' && c.getName() === name; }); }

function collect(channels, canView, roleName) {
  var all = Object.values(channels), cats = {}, out = [];
  all.forEach(function (c) { if (c.type === 4) cats[c.id] = c; });
  all.forEach(function (c) {
    if (c.type === 4) return;
    var ok; try { ok = canView(c); } catch (e) { return; }
    if (ok) return;
    var ow = Object.values(c.permissionOverwrites || {});
    var roles = ow.filter(function (o) { return o.type === 0 && (BigInt(o.allow || 0) & VIEW) !== BigInt(0); })
                  .map(function (o) { return roleName(o.id) || ('role:' + o.id); });
    var members = ow.filter(function (o) { return o.type === 1 && (BigInt(o.allow || 0) & VIEW) !== BigInt(0); }).length;
    var parent = cats[c.parent_id || c.parentId];
    out.push({ name: c.name || '?', type: TYPES[c.type] || ('نوع ' + c.type), category: parent ? parent.name : '—',
               topic: c.topic || '', roles: roles, members: members, position: c.position || 0 });
  });
  return out.sort(function (a, b) { return a.category.localeCompare(b.category) || a.position - b.position; });
}

function fmt(name, list) {
  var s = name + '\nقنوات مخفية: ' + list.length + '\n', last = '';
  for (var i = 0; i < list.length; i++) {
    var h = list[i], b = '';
    if (h.category !== last) { b += '\n▸ ' + h.category + '\n'; last = h.category; }
    b += ' • ' + h.name + ' (' + h.type + ')';
    if (h.roles.length) b += '\n   رتب: ' + h.roles.slice(0, 4).join('، ') + (h.roles.length > 4 ? '…' : '');
    if (h.members) b += '\n   أشخاص: ' + h.members;
    if (h.topic) b += '\n   وصف: ' + h.topic.slice(0, 60);
    b += '\n';
    if ((s + b).length > 1400) return s + '\n… (مقتطعة)';
    s += b;
  }
  return s;
}

function run() {
  var A = findBy(function (c) { return typeof c.alert === 'function' && typeof c.prompt === 'function'; });
  var say = function (t, m, btns) {
    if (A) A.alert(t, m, btns); else console.log(TAG, t, m);
  };
  var Ch = store('ChannelStore'), Gu = store('GuildStore'), Pe = store('PermissionStore'), Ro = store('GuildRoleStore');
  var st = { Alert: !!A, ChannelStore: !!Ch, GuildStore: !!Gu, PermissionStore: !!Pe, GuildRoleStore: !!Ro };
  console.log(TAG, 'stores', JSON.stringify(st));
  var missing = Object.keys(st).filter(function (k) { return !st[k]; });
  if (missing.length || typeof Ch.getMutableGuildChannelsForGuild !== 'function' || typeof Pe.can !== 'function') {
    say('Hidden Channels', 'لم أجد واجهات Discord:\n' + (missing.join(', ') || 'دوال ناقصة') + '\n\nأرسل لي هذه الرسالة.');
    return;
  }
  var guilds = Object.values(Gu.getGuilds ? Gu.getGuilds() : {}), res = [], known = 0;
  guilds.forEach(function (g) {
    var chs = Ch.getMutableGuildChannelsForGuild(g.id) || {};
    known += Object.keys(chs).length;
    var list = collect(chs, function (c) { return Pe.can(VIEW, c); },
      function (id) { var r = Ro.getRole && Ro.getRole(g.id, id); return r && r.name; });
    if (list.length) res.push(fmt(g.name, list));
  });
  console.log(TAG, 'guilds=' + guilds.length, 'known=' + known, 'withHidden=' + res.length);
  if (!res.length) {
    say('Hidden Channels', 'فحصت ' + guilds.length + ' سيرفر (' + known + ' قناة معروفة للتطبيق).\nلا توجد قنوات مخفية وصلت بياناتها لتطبيقك.\n\nهذا يعني على الأرجح أن Discord لا يرسلها للجوال، ولا يمكن لأي إضافة عرضها.');
    return;
  }
  var show = function (i) {
    var b = [{ text: 'إغلاق', style: 'cancel' }];
    if (i + 1 < res.length) b.push({ text: 'السيرفر التالي', onPress: function () { show(i + 1); } });
    say('مخفية (' + (i + 1) + '/' + res.length + ')', res[i], b);
  };
  show(0);
}

var def = __plugin({
  start: function () {
    try {
      var A0 = findBy(function (c) { return typeof c.alert === 'function' && typeof c.prompt === 'function'; });
      if (A0) A0.alert('Hidden Channels', 'الإضافة اشتغلت. ستظهر النتيجة بعد ثوانٍ.');
    } catch (e) { console.error(TAG, e); }
    setTimeout(function () { try { run(); } catch (e) { console.error(TAG, e); } }, 6000);
  },
  stop: function () {}
});
try { if (typeof module !== 'undefined' && module) { module.exports = def; module.exports.default = def; } } catch (e) {}
try { if (typeof exports !== 'undefined' && exports) { exports.default = def; } } catch (e) {}
return def;
